<?php
// Heading
$_['heading_title']    = 'Обратная связь';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Настройки модуля';
$_['text_helper']   = '<code>{# feedback_form #}</code> - вставьте данный шорткод в любую часть страницы, чтобы форма отобразилась';

$_['entry_status'] = 'Статус';

